"use client";
import Home from "@/components/Home";
import React from "react";

import "primereact/resources/themes/saga-blue/theme.css"; // Choose the theme you want
import "primereact/resources/primereact.min.css";
import "primeicons/primeicons.css";

const page = () => {
  return (
    <div className="">
      <Home />
    </div>
  );
};

export default page;
