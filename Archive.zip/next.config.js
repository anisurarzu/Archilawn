// next.config.js
module.exports = {
    images: {
      domains: ['i.ibb.co'], // Add the domain here
    },
  };
  